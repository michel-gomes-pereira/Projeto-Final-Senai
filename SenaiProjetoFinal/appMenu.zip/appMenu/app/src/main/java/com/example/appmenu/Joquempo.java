package com.example.appmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class Joquempo extends AppCompatActivity {
    TextView txt1,txtfim;
    Button btnvoltar,btnreiniciar;

    int pontos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joquempo);
        txt1 = (TextView)  findViewById(R.id.txt_pontuacao);
        txtfim = (TextView) findViewById(R.id.txt_fim);
        btnvoltar = (Button) findViewById(R.id.btn_voltar);
        btnreiniciar = (Button)findViewById(R.id.btn_reiniciar) ;
        btnreiniciar.setVisibility(View.INVISIBLE);


        btnvoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnreiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recreate();
            }
        });

    }
    //criação de métodos
    public void selecionadopedra(View view) {
        this.opcaoselecionada("pedra");
    }

    public void selecionadotesoura(View view) {
        this.opcaoselecionada("tesoura");
    }

    public void selecionadopapel(View view) {
        this.opcaoselecionada("papel");
    }

    public void opcaoselecionada(String opcaoselecionada) {
        ImageView imageResultado = findViewById(R.id.imageResultado);
        TextView txtResultado = findViewById(R.id.txtResultado);
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoApp = opcoes[numero];
        System.out.println("Foi selecionado em " + opcaoselecionada);

        switch (opcaoApp) {
            case "pedra":
                imageResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imageResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imageResultado.setImageResource(R.drawable.tesoura);
                break;
        }

            if(pontos>=20){
                btnreiniciar.setVisibility(View.VISIBLE);
                txtfim.setText("Parabéns!!Agora você pode reinciar o jogo");



            }
            if ((opcaoApp == "tesoura" && opcaoselecionada == "papel") ||
                    (opcaoApp == "papel" && opcaoselecionada == "pedra") ||
                    (opcaoApp == "pedra" && opcaoselecionada == "tesoura")) {

                txtResultado.setText("Você Perdeu");
                pontos = pontos - 1;
                txt1.setText(String.valueOf(pontos));

            } else if ((opcaoselecionada == "tesoura" && opcaoApp == "papel") ||
                    (opcaoselecionada == "papel" && opcaoApp == "pedra") ||
                    (opcaoselecionada == "pedra" && opcaoApp == "tesoura")) {
                txtResultado.setText("Você Ganhou");
                pontos = pontos + 2;
                txt1.setText(String.valueOf(pontos));

            } else {
                txtResultado.setText("Empatamos");
                pontos = pontos + 1;
                txt1.setText(String.valueOf(pontos));
            }

        //btnreiniciar.setVisibility(View.VISIBLE);
    }
}